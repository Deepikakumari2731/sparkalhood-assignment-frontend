import React, { useState } from 'react';
import { Incident, Severity } from '../types';

interface IncidentFormProps {
  onSubmit: (incident: Omit<Incident, 'id'>) => void;
}

const IncidentForm: React.FC<IncidentFormProps> = ({ onSubmit }) => {
  const [isFormVisible, setIsFormVisible] = useState(false);
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [severity, setSeverity] = useState<Severity>('Medium');
  const [errors, setErrors] = useState<{ [key: string]: string }>({});

  const toggleForm = () => {
    setIsFormVisible(!isFormVisible);
  };

  const validateForm = () => {
    const newErrors: { [key: string]: string } = {};
    
    if (!title.trim()) {
      newErrors.title = 'Title is required';
    }
    
    if (!description.trim()) {
      newErrors.description = 'Description is required';
    }
    
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (validateForm()) {
      onSubmit({
        title,
        description,
        severity,
        reported_at: new Date().toISOString(),
      });
      
      // Reset form
      setTitle('');
      setDescription('');
      setSeverity('Medium');
      setErrors({});
      
      // Hide form after successful submission
      setIsFormVisible(false);
    }
  };

  return (
    <div className="mb-8">
      <div className="flex justify-between items-center mb-4">
        <h2 className="text-xl font-semibold text-gray-800">Report New Incident</h2>
        <button
          onClick={toggleForm}
          className="btn btn-primary flex items-center"
        >
          <svg
            className={`mr-1 h-5 w-5 transform transition-transform ${
              isFormVisible ? 'rotate-45' : ''
            }`}
            fill="none"
            viewBox="0 0 24 24"
            stroke="currentColor"
          >
            <path
              strokeLinecap="round"
              strokeLinejoin="round"
              strokeWidth="2"
              d="M12 4v16m8-8H4"
            />
          </svg>
          {isFormVisible ? 'Cancel' : 'New Incident'}
        </button>
      </div>
      
      {isFormVisible && (
        <div className="bg-white rounded-lg shadow animate-fade-in">
          <form onSubmit={handleSubmit} className="p-6">
            <div className="form-group">
              <label htmlFor="title" className="form-label">Title <span className="text-danger-600">*</span></label>
              <input
                type="text"
                id="title"
                value={title}
                onChange={(e) => setTitle(e.target.value)}
                className={`text-input ${errors.title ? 'border-danger-500 focus:ring-danger-500 focus:border-danger-500' : ''}`}
                placeholder="Brief title describing the incident"
              />
              {errors.title && <p className="mt-1 text-sm text-danger-600">{errors.title}</p>}
            </div>
            
            <div className="form-group">
              <label htmlFor="severity" className="form-label">Severity <span className="text-danger-600">*</span></label>
              <select
                id="severity"
                value={severity}
                onChange={(e) => setSeverity(e.target.value as Severity)}
                className="select-input"
              >
                <option value="Low">Low</option>
                <option value="Medium">Medium</option>
                <option value="High">High</option>
              </select>
            </div>
            
            <div className="form-group">
              <label htmlFor="description" className="form-label">Description <span className="text-danger-600">*</span></label>
              <textarea
                id="description"
                value={description}
                onChange={(e) => setDescription(e.target.value)}
                className={`text-input h-32 resize-none ${errors.description ? 'border-danger-500 focus:ring-danger-500 focus:border-danger-500' : ''}`}
                placeholder="Detailed description of the AI safety incident..."
              ></textarea>
              {errors.description && <p className="mt-1 text-sm text-danger-600">{errors.description}</p>}
            </div>
            
            <div className="flex justify-end mt-6">
              <button type="button" onClick={toggleForm} className="btn btn-secondary mr-2">
                Cancel
              </button>
              <button type="submit" className="btn btn-success">
                Submit Report
              </button>
            </div>
          </form>
        </div>
      )}
    </div>
  );
};

export default IncidentForm;