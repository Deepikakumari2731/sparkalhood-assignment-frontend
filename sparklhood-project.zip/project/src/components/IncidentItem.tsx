import React, { useState } from 'react';
import { format } from 'date-fns';
import { Incident } from '../types';

interface IncidentItemProps {
  incident: Incident;
}

const IncidentItem: React.FC<IncidentItemProps> = ({ incident }) => {
  const [isExpanded, setIsExpanded] = useState(false);

  const toggleExpand = () => {
    setIsExpanded(!isExpanded);
  };

  const getSeverityClass = (severity: string) => {
    switch (severity) {
      case 'Low':
        return 'badge-low';
      case 'Medium':
        return 'badge-medium';
      case 'High':
        return 'badge-high';
      default:
        return 'badge-low';
    }
  };

  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    return format(date, 'MMM d, yyyy h:mm a');
  };

  return (
    <div className={`incident-card mb-4 ${isExpanded ? 'ring-2 ring-primary-500' : ''}`}>
      <div className="p-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between">
          <div className="mb-2 sm:mb-0">
            <div className="flex items-center">
              <h3 className="text-lg font-medium text-gray-900">{incident.title}</h3>
              <span className={`ml-2 ${getSeverityClass(incident.severity)}`}>
                {incident.severity}
              </span>
            </div>
            <p className="text-sm text-gray-500">
              Reported: {formatDate(incident.reported_at)}
            </p>
          </div>
          <button
            onClick={toggleExpand}
            className="btn btn-secondary mt-2 sm:mt-0 flex items-center"
          >
            <span>{isExpanded ? 'Hide Details' : 'View Details'}</span>
            <svg
              className={`ml-1 h-5 w-5 transform transition-transform ${
                isExpanded ? 'rotate-180' : ''
              }`}
              fill="none"
              viewBox="0 0 24 24"
              stroke="currentColor"
            >
              <path
                strokeLinecap="round"
                strokeLinejoin="round"
                strokeWidth="2"
                d="M19 9l-7 7-7-7"
              />
            </svg>
          </button>
        </div>
      </div>
      
      {isExpanded && (
        <div className="px-4 pb-4 pt-1 animate-slide-down border-t border-gray-100">
          <h4 className="text-sm font-medium text-gray-700 mb-1">Description:</h4>
          <p className="text-gray-600">{incident.description}</p>
        </div>
      )}
    </div>
  );
};

export default IncidentItem;