import React from 'react';
import { Incident, FilterSeverity, SortOrder } from '../types';
import IncidentItem from './IncidentItem';

interface IncidentListProps {
  incidents: Incident[];
  severityFilter: FilterSeverity;
  sortOrder: SortOrder;
}

const IncidentList: React.FC<IncidentListProps> = ({
  incidents,
  severityFilter,
  sortOrder,
}) => {
  // Filter incidents by severity
  const filteredIncidents = incidents.filter((incident) => {
    if (severityFilter === 'All') return true;
    return incident.severity === severityFilter;
  });

  // Sort incidents by date
  const sortedIncidents = [...filteredIncidents].sort((a, b) => {
    const dateA = new Date(a.reported_at).getTime();
    const dateB = new Date(b.reported_at).getTime();
    return sortOrder === 'newest' ? dateB - dateA : dateA - dateB;
  });

  return (
    <div className="mb-6">
      <h2 className="text-xl font-semibold text-gray-800 mb-4">
        Incident Reports {severityFilter !== 'All' && `(${severityFilter})`}
      </h2>
      
      {sortedIncidents.length === 0 ? (
        <div className="bg-white p-6 rounded-lg shadow text-center">
          <svg
            className="mx-auto h-12 w-12 text-gray-400"
            fill="none"
            viewBox="0 0 24 24"
            stroke="currentColor"
            aria-hidden="true"
          >
            <path
              strokeLinecap="round"
              strokeLinejoin="round"
              strokeWidth="2"
              d="M9.172 16.172a4 4 0 015.656 0M9 10h.01M15 10h.01M12 2C6.477 2 2 6.477 2 12s4.477 10 10 10 10-4.477 10-10S17.523 2 12 2z"
            />
          </svg>
          <h3 className="mt-2 text-sm font-medium text-gray-900">No incidents found</h3>
          <p className="mt-1 text-sm text-gray-500">
            There are no incidents matching your current filters.
          </p>
        </div>
      ) : (
        <div>
          <p className="text-sm text-gray-500 mb-4">
            Showing {sortedIncidents.length} {sortedIncidents.length === 1 ? 'incident' : 'incidents'}
          </p>
          <div className="space-y-4">
            {sortedIncidents.map((incident) => (
              <IncidentItem key={incident.id} incident={incident} />
            ))}
          </div>
        </div>
      )}
    </div>
  );
};

export default IncidentList;