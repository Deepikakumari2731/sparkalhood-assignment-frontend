import React from 'react';
import { FilterSeverity, SortOrder } from '../types';

interface FilterControlsProps {
  activeSeverityFilter: FilterSeverity;
  activeSortOrder: SortOrder;
  onSeverityFilterChange: (severity: FilterSeverity) => void;
  onSortOrderChange: (order: SortOrder) => void;
}

const FilterControls: React.FC<FilterControlsProps> = ({
  activeSeverityFilter,
  activeSortOrder,
  onSeverityFilterChange,
  onSortOrderChange,
}) => {
  return (
    <div className="bg-white rounded-lg shadow p-4 mb-6 animate-fade-in">
      <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
        <div>
          <h2 className="text-sm font-medium text-gray-700 mb-2">Filter by Severity</h2>
          <div className="flex space-x-2">
            {(['All', 'High', 'Medium', 'Low'] as const).map((severity) => (
              <button
                key={severity}
                className={`btn ${
                  activeSeverityFilter === severity
                    ? 'btn-primary'
                    : 'btn-secondary'
                }`}
                onClick={() => onSeverityFilterChange(severity)}
              >
                {severity}
              </button>
            ))}
          </div>
        </div>
        
        <div>
          <h2 className="text-sm font-medium text-gray-700 mb-2">Sort by Date</h2>
          <div className="flex space-x-2">
            <button
              className={`btn ${
                activeSortOrder === 'newest'
                  ? 'btn-primary'
                  : 'btn-secondary'
              }`}
              onClick={() => onSortOrderChange('newest')}
            >
              Newest First
            </button>
            <button
              className={`btn ${
                activeSortOrder === 'oldest'
                  ? 'btn-primary'
                  : 'btn-secondary'
              }`}
              onClick={() => onSortOrderChange('oldest')}
            >
              Oldest First
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default FilterControls;