import React from 'react';

const Header: React.FC = () => {
  return (
    <header className="bg-primary-600 text-white py-4 md:py-6">
      <div className="container mx-auto px-4">
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center">
          <div>
            <h1 className="text-2xl md:text-3xl font-bold">AI Safety Incident Dashboard</h1>
            <p className="text-primary-100 mt-1">HumanChain - Building a safer AI future</p>
          </div>
          <div className="mt-2 md:mt-0">
            <div className="bg-primary-700 rounded-md px-3 py-1 text-xs font-medium inline-flex items-center">
              <span className="inline-block w-2 h-2 rounded-full bg-green-400 mr-2"></span>
              MONITORING ACTIVE
            </div>
          </div>
        </div>
      </div>
    </header>
  );
};

export default Header;