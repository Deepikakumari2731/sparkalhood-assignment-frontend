import React, { useState } from 'react';
import { Incident, FilterSeverity, SortOrder } from './types';
import { initialIncidents } from './data/mockData';
import Header from './components/Header';
import FilterControls from './components/FilterControls';
import IncidentList from './components/IncidentList';
import IncidentForm from './components/IncidentForm';
import Footer from './components/Footer';

const App: React.FC = () => {
  const [incidents, setIncidents] = useState<Incident[]>(initialIncidents);
  const [severityFilter, setSeverityFilter] = useState<FilterSeverity>('All');
  const [sortOrder, setSortOrder] = useState<SortOrder>('newest');

  const handleSeverityFilterChange = (severity: FilterSeverity) => {
    setSeverityFilter(severity);
  };

  const handleSortOrderChange = (order: SortOrder) => {
    setSortOrder(order);
  };

  const handleIncidentSubmit = (newIncident: Omit<Incident, 'id'>) => {
    // Generate a new ID (in a real app, this would be handled by the backend)
    const newId = Math.max(0, ...incidents.map(inc => inc.id)) + 1;
    
    const incidentWithId: Incident = {
      ...newIncident,
      id: newId,
    };
    
    setIncidents([...incidents, incidentWithId]);
  };

  return (
    <div className="flex flex-col min-h-screen">
      <Header />
      
      <main className="container mx-auto px-4 py-8 flex-grow">
        <div className="mb-8">
          <h2 className="text-2xl font-bold text-gray-900 mb-2">Dashboard Overview</h2>
          <p className="text-gray-600">
            Monitor and manage AI safety incidents across your organization's AI systems.
            Filter, sort, and report new incidents as they occur.
          </p>
        </div>
        
        <FilterControls
          activeSeverityFilter={severityFilter}
          activeSortOrder={sortOrder}
          onSeverityFilterChange={handleSeverityFilterChange}
          onSortOrderChange={handleSortOrderChange}
        />
        
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          <div className="lg:col-span-2">
            <IncidentList
              incidents={incidents}
              severityFilter={severityFilter}
              sortOrder={sortOrder}
            />
          </div>
          
          <div className="lg:col-span-1">
            <IncidentForm onSubmit={handleIncidentSubmit} />
            
            <div className="bg-white rounded-lg shadow p-4">
              <h3 className="text-lg font-medium text-gray-900 mb-3">Incident Severity Guide</h3>
              <div className="space-y-3">
                <div>
                  <div className="flex items-center mb-1">
                    <span className="badge-high mr-2">High</span>
                    <span className="font-medium">Critical Impact</span>
                  </div>
                  <p className="text-sm text-gray-600">Serious safety concerns, potential for harm, immediate attention required</p>
                </div>
                <div>
                  <div className="flex items-center mb-1">
                    <span className="badge-medium mr-2">Medium</span>
                    <span className="font-medium">Moderate Impact</span>
                  </div>
                  <p className="text-sm text-gray-600">Significant issues with limited immediate risk, requires prompt attention</p>
                </div>
                <div>
                  <div className="flex items-center mb-1">
                    <span className="badge-low mr-2">Low</span>
                    <span className="font-medium">Minor Impact</span>
                  </div>
                  <p className="text-sm text-gray-600">Minor issues with minimal risk, standard follow-up required</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </main>
      
      <Footer />
    </div>
  );
};

export default App;