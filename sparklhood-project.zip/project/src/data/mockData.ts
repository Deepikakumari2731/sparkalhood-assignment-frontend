import { Incident } from '../types';

export const initialIncidents: Incident[] = [
  {
    id: 1, 
    title: "Biased Recommendation Algorithm", 
    description: "Algorithm consistently favored certain demographics in hiring recommendations, leading to potential discrimination. The bias was detected during routine audit of output data patterns.", 
    severity: "Medium", 
    reported_at: "2025-03-15T10:00:00Z"
  },
  {
    id: 2, 
    title: "LLM Hallucination in Critical Info", 
    description: "Large Language Model provided incorrect safety procedure information for handling hazardous materials in a manufacturing context. The hallucination was detected before implementation but represents a serious potential safety risk.", 
    severity: "High", 
    reported_at: "2025-04-01T14:30:00Z"
  },
  {
    id: 3, 
    title: "Minor Data Leak via Chatbot", 
    description: "Chatbot inadvertently exposed non-sensitive user metadata in conversation logs. The leak was contained to internal systems and no personally identifiable information was compromised.", 
    severity: "Low", 
    reported_at: "2025-03-20T09:15:00Z"
  },
  {
    id: 4,
    title: "Autonomous System False Alarm",
    description: "Self-driving vehicle system incorrectly identified roadwork as an obstruction, causing unnecessary emergency braking. No accidents occurred, but the incident could have led to rear-end collisions.",
    severity: "Medium",
    reported_at: "2025-03-22T11:45:00Z"
  },
  {
    id: 5,
    title: "AI Healthcare Diagnostic Error",
    description: "Diagnostic AI system missed a critical indicator in radiological images that human doctors caught. Investigation revealed a blind spot in the training data for certain rare conditions.",
    severity: "High",
    reported_at: "2025-03-30T16:20:00Z"
  },
  {
    id: 6,
    title: "Content Moderation Overreach",
    description: "AI content moderation system flagged educational content about historical events as violating community guidelines. The issue appeared to stem from context misinterpretation.",
    severity: "Low",
    reported_at: "2025-03-25T13:10:00Z"
  }
];