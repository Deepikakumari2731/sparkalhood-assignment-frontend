# AI Safety Incident Dashboard

A frontend interface to view and log hypothetical AI safety incidents, built for HumanChain.

## Features

- Display a list of AI safety incidents with title, severity, and reported date
- Filter incidents by severity (All, Low, Medium, High)
- Sort incidents by reported date (newest/oldest first)
- Expand incident details with a toggle
- Report new incidents with a form and basic validation
- Responsive design that works on all devices

## Tech Stack

- React with TypeScript
- Tailwind CSS for styling
- date-fns for date formatting
- Vite for build tooling

## Getting Started

### Prerequisites

- Node.js (v14.x or higher)
- npm or yarn

### Installation

1. Clone the repository
2. Install dependencies:

```bash
npm install
```

3. Start the development server:

```bash
npm run dev
```

4. Open your browser and navigate to the URL shown in your terminal (typically http://localhost:5173)

### Building for Production

```bash
npm run build
```

The built files will be in the `dist` directory.

## Design Decisions

- Used Tailwind CSS for rapid UI development and consistent styling
- Implemented a modular component structure for maintainability
- Added subtle animations for better user experience
- Created a responsive layout that works well on all device sizes
- Used a professional color scheme that indicates severity levels